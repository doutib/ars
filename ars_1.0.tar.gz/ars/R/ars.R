#' Adaptive rejection sampler
#' The main ars() function
#' @param h The log of the density function
#' @param n The number of points to be sampled
#' @param domain A vector of length 2 giving the domain (left bound, right bound) of the density function
#' @param x1 The leftmost node of the abscissae, if not provided, the abscissae() will try to find one which has a suitable slope, leading to a unbiased and numerical-issues friendly sampling process
#' @param xk The the rightmost node of the abscissae, if not provided, the abscissae() will try to find one which has a suitable slope, leading to a unbiased and numerical-issues friendly sampling process
#' @param x0 See ?abscissae. default = 0
#' @param nmesh See ?abscissae. default = 5
#' @param x_start See ?search. default = 0
#' @param max_x See ?search. default = 10000
#' @param min_step See ?search. default = .01
#' @param relax_factor See ?search. default = 10
#' @examples
#' h <- function (x){
#' log (dnorm (x, 0, 1))
#' }
#' samples <- ars(h, 10000, c(-Inf, Inf))
require('pracma')
ars <-
function(h,n,domain,x1 = NULL,xk = NULL,x0=0,nmesh=5,
                x_start=0,max_x=10000,min_step=0.01,relax_factor=10)
{
  n_sampled <- 0
  x_sample <- vector("numeric")
  first_run <-TRUE
  while(n_sampled < n)
  {
    if(first_run)
    { 
      if(is.infinite(domain[1])& is.infinite(domain[2]))
      {
        tmp <- search(h,c(-Inf,Inf),x_start,max_x,min_step,relax_factor)
        x <- abscissae(h,c(-Inf,Inf),x1,xk,x0=tmp,nmesh,min_step,relax_factor)
      } else{x <- abscissae(h,domain,x1,xk,x0,nmesh,min_step,relax_factor)}
      u <- envelop(h,x,domain)
      l <- squeezing(h,x)
      if(log_concavity(u,l))
      {
        warning('local log non-concavity detected,check input density function!')
      }
      s <- envelop_density(h,x,domain)
    }
    x_sampled <-sample_one_point(s)
    
    pass_squeezing <- squeezing_test(x_sampled,l,u)
    if(!pass_squeezing)
    {
      pass_rejection<-rejection_test(x_sampled,u,h)
    }
    if (pass_squeezing || pass_rejection)
    {
      n_sampled=n_sampled+1
      x_sample[n_sampled]<-x_sampled[1]
      if (!pass_squeezing)
      {
        x <-update_grid(x,x_sampled[1])
        u <- envelop(h,x,domain)
        l <- squeezing(h,x)
        if(log_concavity(u,l))
        {
          warning('local log non-concavity detected,check input density function!')
        }
        s <- envelop_density(h,x,domain)  
      }
    }
    first_run <- FALSE
  }
  return(x_sample)
}
